from .screeninfo import Monitor, get_monitors
